﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void SendMessage_Click(object sender, RoutedEventArgs e)
        {
            string message = new TextRange(messageTextBox.Document.ContentStart, messageTextBox.Document.ContentEnd).Text;

            CreateAndAddNewLabel(message);
            messageTextBox.Document.Blocks.Clear();
        }
        private void CreateAndAddNewLabel(string message)
        {
            TextBlock messageText = new TextBlock
            {
                Text = message,
                Background = Brushes.WhiteSmoke,
                Foreground = Brushes.Black,
                FontSize = 14,
                FontWeight = FontWeights.Bold,
                Width = double.NaN,
                MaxWidth = 200,
                Margin = new Thickness(0, 5, 0, 0),
                TextWrapping = TextWrapping.Wrap
            };

            TextBlock timeText = new TextBlock
            {
                Text = DateTime.Now.ToString("HH:mm"), 
                Foreground = Brushes.Gray,
                Margin = new Thickness(0, 0, 0, 5),
                HorizontalAlignment = HorizontalAlignment.Right,
            };

            StackPanel messageWithTime = new StackPanel
            {
                Orientation = Orientation.Vertical,
                Children = { messageText, timeText },
            };

            Border border = new Border
            {
                Background = Brushes.WhiteSmoke,
                CornerRadius = new CornerRadius(10),
                Padding = new Thickness(5),
                BorderThickness = new Thickness(1),
                BorderBrush = Brushes.Black,
                Margin = new Thickness(5),
                Width = double.NaN, 
                HorizontalAlignment = HorizontalAlignment.Right,
                Child = messageWithTime,
            };

            messageContainer.Children.Add(border);
        }
    }
}
